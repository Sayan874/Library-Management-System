from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from datetime import datetime

from app.routes import books, members, issues
from app.database.connection import get_database

load_dotenv()

app = FastAPI(
    title="Library Management System",
    description="API for managing books, members, and book issues/returns",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(books.router, prefix="/api/books", tags=["Books"])
app.include_router(members.router, prefix="/api/members", tags=["Members"])
app.include_router(issues.router, prefix="/api/issues", tags=["Issues"])


@app.get("/")
def root():
    return {"message": "Library Management System API is running"}


@app.get("/api/stats")
def get_stats():
    db = get_database()
    total_books = db["books"].count_documents({})
    total_members = db["members"].count_documents({})
    active_issues = db["issues"].count_documents({"status": "Issued"})
    today_iso = datetime.utcnow().date().isoformat()
    overdue = db["issues"].count_documents(
        {"status": "Issued", "due_date": {"$lt": today_iso}}
    )
    available_books = db["books"].aggregate([
        {"$group": {"_id": None, "total": {"$sum": "$available_copies"}}}
    ])
    available_sum = next(available_books, {}).get("total", 0)
    return {
        "total_books": total_books,
        "total_members": total_members,
        "active_issues": active_issues,
        "overdue": overdue,
        "available_copies": available_sum,
    }
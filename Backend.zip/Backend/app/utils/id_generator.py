def generate_book_id(db):
    count = db["books"].count_documents({})
    return f"LIB-BK-{str(count + 1).zfill(4)}"

def generate_member_id(db):
    count = db["members"].count_documents({})
    return f"LIB-MEM-{str(count + 1).zfill(4)}"

def generate_issue_id(db):
    count = db["issues"].count_documents({})
    return f"ISS-{str(count + 1).zfill(4)}"

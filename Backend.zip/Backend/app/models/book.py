from pydantic import BaseModel
from typing import Optional


class BookCreate(BaseModel):
    title: str
    author: str
    isbn: str
    genre: str
    total_copies: int
    publisher: Optional[str] = None
    year: Optional[int] = None


class BookUpdate(BaseModel):
    title: Optional[str] = None
    author: Optional[str] = None
    isbn: Optional[str] = None
    genre: Optional[str] = None
    total_copies: Optional[int] = None
    publisher: Optional[str] = None
    year: Optional[int] = None
    status: Optional[str] = None

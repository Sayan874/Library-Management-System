from pydantic import BaseModel
from typing import Optional


class IssueCreate(BaseModel):
    book_id: str
    member_id: str
    due_date: str  # ISO date string e.g. "2025-08-15"
